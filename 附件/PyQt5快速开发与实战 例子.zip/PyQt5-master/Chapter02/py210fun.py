# -*- coding: utf-8 -*-
 
fun1 = lambda x,y : x + y  
print('fun1(2,3)=' , fun1(2,3))

fun2 = lambda x: x*2
print('fun2(4)=' , fun2(4) )